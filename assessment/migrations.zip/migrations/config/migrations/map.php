<?php
$map = array(
	1 => array('001_init_migrations' => 'M4af6e0f0a1284147a0b100ca58157726')
);
?>