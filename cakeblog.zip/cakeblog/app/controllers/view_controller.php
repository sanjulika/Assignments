<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ViewController
 *
 * @author mady
 */
class ViewController extends AppController {

	var $name = 'View';
        function posts_1() {
                
	}
        function posts_2() {

	}
        function posts_3() {
echo "I am 3rd blog writen in controller";
	}
}
?>
