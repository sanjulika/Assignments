<?php
class AppController extends Controller {
/*function beforeFilter(){
    parent::beforeFilter();
}*/
}
?>
